//  Copyright Snap Inc. All rights reserved.
//  CameraKit

#import <Foundation/Foundation.h>

NS_SWIFT_NAME(Texture)
/// An opaque protocol describing CameraKit output.
@protocol SCCameraKitTexture <NSObject>

@end
